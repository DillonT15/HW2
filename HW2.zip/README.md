Project for CSC 235 Based on a yahtzee game using HTML, CSS and javascript.
